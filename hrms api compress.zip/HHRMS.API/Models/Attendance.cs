﻿namespace HHRMS.API.Models
{
    public class Attendance
    {
        public int AttendanceId { get; set; }

        public string Employee { get; set; }

        public string Date { get; set; }

        public string Status { get; set; }

        public string CheckIn { get; set; }

        public string CheckOut { get; set; }
    }
}