﻿namespace HHRMS.API.Models
{
    public class Payroll
    {
        public int PayrollId { get; set; }

        public string Employee { get; set; }

        public string Month { get; set; }

        public decimal BasicSalary { get; set; }

        public decimal Bonus { get; set; }

        public decimal Deductions { get; set; }

        public decimal NetSalary { get; set; }

        public string Status { get; set; }
    }
}