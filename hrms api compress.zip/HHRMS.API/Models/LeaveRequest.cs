﻿namespace HHRMS.API.Models
{
    public class LeaveRequest
    {
        public int LeaveId { get; set; }

        public string Employee { get; set; }

        public string LeaveType { get; set; }

        public string FromDate { get; set; }

        public string ToDate { get; set; }

        public int Days { get; set; }

        public string Reason { get; set; }

        public string Status { get; set; }
    }
}