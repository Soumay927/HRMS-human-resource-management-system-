﻿using System;
namespace HHRMS.API.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeCode { get; set; }

        public string FullName { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string Department { get; set; }

        public string Designation { get; set; }

        public decimal Salary { get; set; }

        public DateTime CreatedDate { get; set; }
    }
}

