﻿using System.Data.Entity;
using HHRMS.API.Models;

namespace HHRMS.API.Data
{
    public class HHRMSDbContext : DbContext
    {
        public HHRMSDbContext()
            : base("niitessConnection")
        {
        }

        public DbSet<User> Users { get; set; }

        public DbSet<Employee> Employees { get; set; }
       
        public DbSet<Department> Departments { get; set; }
    }
}