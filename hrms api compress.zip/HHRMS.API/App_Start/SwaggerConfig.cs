using Swashbuckle.Application;
using System.Web.Http;

//[assembly: PreApplicationStartMethod(typeof(HHRMS.API.SwaggerConfig), "Register")]

namespace HHRMS.API
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                {
                    c.SingleApiVersion("v1", "HHRMS API");
                })
                .EnableSwaggerUi();
        }
    }
}
