﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using HHRMS.API.Models;

namespace HHRMS.API.Controllers
{
    [RoutePrefix("api/attendance")]
    public class AttendanceController : ApiController
    {
        private static List<Attendance> attendanceList =
            new List<Attendance>()
            {
                new Attendance
                {
                    AttendanceId = 1,
                    Employee = "Soumay",
                    Date = "2026-08-06",
                    Status = "Present",
                    CheckIn = "09:30 AM",
                    CheckOut = "06:00 PM"
                },
                new Attendance
                {
                    AttendanceId = 2,
                    Employee = "Rahul",
                    Date = "2026-08-06",
                    Status = "Absent",
                    CheckIn = "-",
                    CheckOut = "-"
                }
            };

        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll()
        {
            return Ok(attendanceList);
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult Add(Attendance attendance)
        {
            attendance.AttendanceId = attendanceList.Count + 1;

            if (attendance.Status == "Absent")
            {
                attendance.CheckIn = "-";
                attendance.CheckOut = "-";
            }

            attendanceList.Add(attendance);

            return Ok(attendance);
        }

        [HttpDelete]
        [Route("{id:int}")]
        public IHttpActionResult Delete(int id)
        {
            var record = attendanceList.FirstOrDefault(x => x.AttendanceId == id);

            if (record == null)
                return NotFound();

            attendanceList.Remove(record);

            return Ok("Attendance Deleted