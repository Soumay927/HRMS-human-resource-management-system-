﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using HHRMS.API.Models;

namespace HHRMS.API.Controllers
{
    [RoutePrefix("api/departments")]
    public class DepartmentsController : ApiController
    {
        private static List<Department> departments =
            new List<Department>()
            {
                new Department
                {
                    DepartmentId = 1,
                    DepartmentName = "IT",
                    Description = "Information Technology Department"
                },
                new Department
                {
                    DepartmentId = 2,
                    DepartmentName = "HR",
                    Description = "Human Resource Department"
                }
            };

        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll()
        {
            return Ok(departments);
        }

        [HttpGet]
        [Route("{id}")]
        public IHttpActionResult GetById(int id)
        {
            var dept = departments.FirstOrDefault(x => x.DepartmentId == id);

            if (dept == null)
                return NotFound();

            return Ok(dept);
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult Add(Department department)
        {
            departments.Add(department);

            return Ok(department);
        }

        [HttpDelete]
        [Route("{id}")]
        public IHttpActionResult Delete(int id)
        {
            var dept = departments.FirstOrDefault(x => x.DepartmentId == id);

            if (dept == null)
                return NotFound();

            departments.Remove(dept);

            return Ok("Department Deleted");
        }
    }
}