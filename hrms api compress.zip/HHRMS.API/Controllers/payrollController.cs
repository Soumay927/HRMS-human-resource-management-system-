﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using HHRMS.API.Models;

namespace HHRMS.API.Controllers
{
    [RoutePrefix("api/payroll")]
    public class PayrollController : ApiController
    {
        private static List<Payroll> payrolls =
            new List<Payroll>()
            {
                new Payroll
                {
                    PayrollId = 1,
                    Employee = "Soumay",
                    Month = "August 2026",
                    BasicSalary = 50000,
                    Bonus = 3000,
                    Deductions = 2000,
                    NetSalary = 51000,
                    Status = "Paid"
                },
                new Payroll
                {
                    PayrollId = 2,
                    Employee = "Rahul",
                    Month = "August 2026",
                    BasicSalary = 40000,
                    Bonus = 2000,
                    Deductions = 1500,
                    NetSalary = 40500,
                    Status = "Pending"
                }
            };

        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll()
        {
            return Ok(payrolls);
        }

        [HttpGet]
        [Route("{id:int}")]
        public IHttpActionResult GetById(int id)
        {
            var payroll = payrolls.FirstOrDefault(x => x.PayrollId == id);

            if (payroll == null)
            {
                return NotFound();
            }

            return Ok(payroll);
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult Add(Payroll payroll)
        {
            payroll.PayrollId = payrolls.Count + 1;

            payroll.NetSalary =
                payroll.BasicSalary + payroll.Bonus - payroll.Deductions;

            payroll.Status = "Pending";

            payrolls.Add(payroll);

            return Ok(payroll);
        }

        [HttpPut]
        [Route("{id:int}/paid")]
        public IHttpActionResult MarkPaid(int id)
        {
            var payroll = payrolls.FirstOrDefault(x => x.PayrollId == id);

            if (payroll == null)
            {
                return NotFound();
            }

            payroll.Status = "Paid";

            return Ok(payroll);
        }

        [HttpDelete]
        [Route("{id:int}")]
        public IHttpActionResult Delete(int id)
        {
            var payroll = payrolls.FirstOrDefault(x => x.PayrollId == id);

            if (payroll == null)
            {
                return NotFound();
            }

            payrolls.Remove(payroll);

            return Ok("Payroll Deleted");
        }
    }
}