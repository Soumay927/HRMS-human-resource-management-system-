﻿using System;
using System.Linq;
using System.Web.Http;
using HHRMS.API.Data;
using HHRMS.API.Models;
namespace HHRMS.API.Controllers
{
    [RoutePrefix("api/employees")]
    public class EmployeesController : ApiController
    {
        private HHRMSDbContext db = new HHRMSDbContext();
        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll()
        {
            var employees = db.Employees.ToList();

            return Ok(employees);
        }

        [HttpGet]
        [Route("dbcheck")]
        public IHttpActionResult DbCheck()
        {
            return Ok(new
            {
                Database = db.Database.Connection.Database,
                DataSource = db.Database.Connection.DataSource,
                EmployeeCount = db.Employees.Count()
            });
        }

        [HttpGet]
        [Route("testinsert")]
        public IHttpActionResult TestInsert()
        {
            var employee = new Employee
            {
                EmployeeCode = "EMPTEST",
                FullName = "Database Test",
                Email = "dbtest@test.com",
                Phone = "9999999999",
                Department = "IT",
                Designation = "Tester",
                Salary = 30000,
                CreatedDate = DateTime.Now
            };

            db.Employees.Add(employee);
            db.SaveChanges();

            return Ok("Employee inserted successfully");
        }

        [HttpGet]
        [Route("{id:int}")]
        public IHttpActionResult GetById(int id)
        {
            var employee = db.Employees.Find(id);

            if (employee == null)
                return NotFound();

            return Ok(employee);
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult Add(Employee employee)
        {
            employee.CreatedDate = DateTime.Now;

            db.Employees.Add(employee);
            db.SaveChanges();

            return Ok(employee);
        }

        [HttpPut]
        [Route("{id:int}")]
        public IHttpActionResult Update(int id, Employee employee)
        {
            var emp = db.Employees.Find(id);

            if (emp == null)
                return NotFound();

            emp.EmployeeCode = employee.EmployeeCode;
            emp.FullName = employee.FullName;
            emp.Email = employee.Email;
            emp.Phone = employee.Phone;
            emp.Department = employee.Department;
            emp.Designation = employee.Designation;
            emp.Salary = employee.Salary;

            db.SaveChanges();

            return Ok(emp);
        }

        [HttpDelete]
        [Route("{id:int}")]
        public IHttpActionResult Delete(int id)
        {
            var emp = db.Employees.Find(id);

            if (emp == null)
                return NotFound();

            db.Employees.Remove(emp);
            db.SaveChanges();

            return Ok("Employee deleted successfully");
        }
    }
}


