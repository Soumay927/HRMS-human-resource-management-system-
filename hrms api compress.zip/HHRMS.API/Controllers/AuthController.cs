﻿using System.Web.Http;
using HHRMS.API.Models;

namespace HHRMS.API.Controllers
{
    [RoutePrefix("api/auth")]
    public class AuthController : ApiController
    {
        [HttpPost]
        [Route("login")]
        public IHttpActionResult Login(LoginModel model)
        {
            if (model.Username == "admin"
                && model.Password == "admin123")
            {
                return Ok(new
                {
                    Message = "Login Successful"
                });
            }

            return Unauthorized();
        }
    }
}