﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using HHRMS.API.Models;

namespace HHRMS.API.Controllers
{
    [RoutePrefix("api/leaves")]
    public class LeavesController : ApiController
    {
        private static List<LeaveRequest> leaves =
            new List<LeaveRequest>()
            {
                new LeaveRequest
                {
                    LeaveId = 1,
                    Employee = "Soumay",
                    LeaveType = "Sick Leave",
                    FromDate = "06 Aug 2026",
                    ToDate = "07 Aug 2026",
                    Days = 2,
                    Reason = "Health issue",
                    Status = "Pending"
                },
                new LeaveRequest
                {
                    LeaveId = 2,
                    Employee = "Rahul",
                    LeaveType = "Casual Leave",
                    FromDate = "08 Aug 2026",
                    ToDate = "08 Aug 2026",
                    Days = 1,
                    Reason = "Personal work",
                    Status = "Approved"
                }
            };

        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll()
        {
            return Ok(leaves);
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult Add(LeaveRequest leave)
        {
            leave.LeaveId = leaves.Count + 1;

            if (leave.Days == 0)
            {
                leave.Days = 1;
            }

            leave.Status = "Pending";

            leaves.Add(leave);

            return Ok(leave);
        }

        [HttpPut]
        [Route("{id:int}/approve")]
        public IHttpActionResult Approve(int id)
        {
            var leave = leaves.FirstOrDefault(x => x.LeaveId == id);

            if (leave == null)
                return NotFound();

            leave.Status = "Approved";

            return Ok(leave);
        }

        [HttpPut]
        [Route("{id:int}/reject")]
        public IHttpActionResult Reject(int id)
        {
            var leave = leaves.FirstOrDefault(x => x.LeaveId == id);

            if (leave == null)
                return NotFound();

            leave.Status = "Rejected";

            return Ok(leave);
        }

        [HttpDelete]
        [Route("{id:int}")]
        public IHttpActionResult Delete(int id)
        {
            var leave = leaves.FirstOrDefault(x => x.LeaveId == id);

            if (leave == null)
                return NotFound();

            leaves.Remove(leave);

            return Ok("Leave Deleted");
        }
    }
}